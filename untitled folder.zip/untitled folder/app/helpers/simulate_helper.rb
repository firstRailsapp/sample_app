module SimulateHelper
  def increment_count(count)
   # selp.progress_bar = count
  end
    
end





class SimulatePage < ActiveRecord::Base
   
end
